Version 0.1 - First "Playble build"

An extremely buggy and early on Version of Minmon Arena.  The first, technically playable version. Test bot is the only minmon available.  Made in godot V3.3.3

----------

Hello, welcome to Minmon Arena.  This is a short demo that allows two people to have a match against eachother.

Controls
W - Up
A - Left
S - Down
D - Right
E - Continue
F - Back

Click the start button to start.  Upon pressing start, you will be thrown into a battle.  While on the top menu to see what moves and minmon do, select the magnifying glass icon.  You will then be taken to a page that explains what everything does.  To get out of it simply press back.

When pressing fight you will be put into the fight menu.  From here you can select what action your minmon will take this turn.  You can choose from 4 moves along with some other options.

Switch - Switches the minmon with one from your reserves
Swap - Makes your two active minmon switch places.  The minmon who uses this will have their defenses lowered by 1, and will continue to lose defence on contructive uses until it does something else.
Burst - Once per battle, you can activate a burst on one of your minmon.  This lasts 3 turns, and boosts your minmon's attacking and defenseive stats.  Switching your minmon out will end the burst early.

The goal is to faint all of your opponets Minmon before they faint all of yours.  Have fun!